# `torchplate.experiment`

This page provides an overview of the main module in torchplate: `torchplate.experiment` which houses `torchplate.experiment.Experiment`. 

(to be updated...)