# `torchplate`: Minimal Experiment Workflows in PyTorch 

An extremely minimal and simple experiment module for machine learning in PyTorch. 

In addition to abstracting away the training loop, we provide several abstractions to improve the efficiency of machine learning workflows with PyTorch. 


